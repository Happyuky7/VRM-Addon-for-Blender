import uuid
from collections.abc import Iterator, ValuesView
from typing import TYPE_CHECKING, Optional, Protocol, TypeVar, overload

import bpy

from ..common.logging import get_logger
from ..common.vrm0 import human_bone as vrm0_human_bone
from ..common.vrm1 import human_bone as vrm1_human_bone

HumanBoneSpecification = TypeVar(
    "HumanBoneSpecification",
    vrm0_human_bone.HumanBoneSpecification,
    vrm1_human_bone.HumanBoneSpecification,
)

logger = get_logger(__name__)


class StringPropertyGroup(bpy.types.PropertyGroup):
    def get_value(self) -> str:
        value = self.get("value")
        if isinstance(value, str):
            return value
        return str(value)

    def set_value(self, value: str) -> None:
        self.name = value  # pylint: disable=attribute-defined-outside-init
        self["value"] = value

    value: bpy.props.StringProperty(  # type: ignore[valid-type]
        name="String Value",  # noqa: F722
        get=get_value,
        set=set_value,
    )

    if TYPE_CHECKING:
        # This code is auto generated.
        # `poetry run ./scripts/property_typing.py`
        value: str  # type: ignore[no-redef]


class FloatPropertyGroup(bpy.types.PropertyGroup):
    def get_value(self) -> float:
        value = self.get("value")
        if isinstance(value, (float, int)):
            return float(value)
        return 0.0

    def set_value(self, value: float) -> None:
        self.name = str(value)  # pylint: disable=attribute-defined-outside-init
        self["value"] = value

    value: bpy.props.FloatProperty(  # type: ignore[valid-type]
        name="Float Value",  # noqa: F722
        get=get_value,
        set=set_value,
    )

    if TYPE_CHECKING:
        # This code is auto generated.
        # `poetry run ./scripts/property_typing.py`
        value: float  # type: ignore[no-redef]


class MeshObjectPropertyGroup(bpy.types.PropertyGroup):
    def get_mesh_object_name(self) -> str:
        if (
            not self.bpy_object
            or not self.bpy_object.name
            or self.bpy_object.type != "MESH"
        ):
            return ""
        return str(self.bpy_object.name)

    def set_mesh_object_name(self, value: object) -> None:
        if (
            not isinstance(value, str)
            or value not in bpy.data.objects
            or bpy.data.objects[value].type != "MESH"
        ):
            self.bpy_object = None
            return
        self.bpy_object = bpy.data.objects[value]

    mesh_object_name: bpy.props.StringProperty(  # type: ignore[valid-type]
        get=get_mesh_object_name, set=set_mesh_object_name
    )

    def get_value(self) -> str:
        logger.warning(
            "MeshObjectPropertyGroup.value is deprecated."
            + " Use MeshObjectPropertyGroup.mesh_object_name instead."
        )
        return str(self.mesh_object_name)

    def set_value(self, value: str) -> None:
        logger.warning(
            "MeshObjectPropertyGroup.value is deprecated."
            + " Use MeshObjectPropertyGroup.mesh_object_name instead."
        )
        self.mesh_object_name = value

    # "value" is deprecated. Use "mesh_object_name" instead
    value: bpy.props.StringProperty(  # type: ignore[valid-type]
        get=get_value,
        set=set_value,
    )

    bpy_object: bpy.props.PointerProperty(  # type: ignore[valid-type]
        type=bpy.types.Object  # noqa: F722
    )

    if TYPE_CHECKING:
        # This code is auto generated.
        # `poetry run ./scripts/property_typing.py`
        mesh_object_name: str  # type: ignore[no-redef]
        value: str  # type: ignore[no-redef]
        bpy_object: Optional[bpy.types.Object]  # type: ignore[no-redef]


class BonePropertyGroup(bpy.types.PropertyGroup):
    @staticmethod
    def get_all_bone_property_groups(
        armature: bpy.types.Object,
    ) -> Iterator["BonePropertyGroup"]:
        armature_data = armature.data
        if not isinstance(armature_data, bpy.types.Armature):
            return
        ext = armature_data.vrm_addon_extension
        yield ext.vrm0.first_person.first_person_bone
        for human_bone in ext.vrm0.humanoid.human_bones:
            yield human_bone.node
        for collider_group in ext.vrm0.secondary_animation.collider_groups:
            yield collider_group.node
        for bone_group in ext.vrm0.secondary_animation.bone_groups:
            yield bone_group.center
            yield from bone_group.bones
        for (
            human_bone
        ) in ext.vrm1.humanoid.human_bones.human_bone_name_to_human_bone().values():
            yield human_bone.node
        for collider in ext.spring_bone1.colliders:
            yield collider.node
        for spring in ext.spring_bone1.springs:
            yield spring.center
            for joint in spring.joints:
                yield joint.node

    @staticmethod
    def find_bone_candidates(
        armature_data: bpy.types.Armature,
        target: HumanBoneSpecification,
        bpy_bone_name_to_human_bone_specification: dict[str, HumanBoneSpecification],
    ) -> set[str]:
        bones = armature_data.bones
        result: set[str] = set(bones.keys())
        remove_bones_tree: set[bpy.types.Bone] = set()

        for (
            bpy_bone_name,
            human_bone_specification,
        ) in bpy_bone_name_to_human_bone_specification.items():
            if human_bone_specification == target:
                continue

            parent = bones.get(bpy_bone_name)
            if not parent:
                continue

            if human_bone_specification.is_ancestor_of(target):
                # logger.debug(f"Ancestor of target: {parent.name}")
                remove_ancestors = True
                remove_ancestor_branches = True
            elif target.is_ancestor_of(human_bone_specification):
                # logger.debug(f"Target is ancestor of: {parent.name}")
                remove_bones_tree.add(parent)
                remove_ancestors = False
                remove_ancestor_branches = True
            else:
                # logger.debug(f"Unrelated/Descendant: {parent.name}")
                remove_bones_tree.add(parent)
                remove_ancestors = True
                remove_ancestor_branches = False

            while True:
                # if remove_ancestors: logger.debug(f"Removing ancestor: {parent.name}")
                if remove_ancestors and parent.name in result:
                    result.remove(parent.name)
                grand_parent = parent.parent
                if not grand_parent:
                    if remove_ancestor_branches:
                        # logger.debug(f"Removing ancestor branches, except: {parent.name}")
                        remove_bones_tree.update(
                            bone
                            for bone in bones.values()
                            if not bone.parent and bone != parent
                        )
                    break

                if remove_ancestor_branches:
                    # logger.debug(f"Removing branches of: {grand_parent.name}")
                    for grand_parent_child in grand_parent.children:
                        if grand_parent_child != parent:
                            remove_bones_tree.add(grand_parent_child)

                parent = grand_parent

        while remove_bones_tree:
            child = remove_bones_tree.pop()
            if child.name in result:
                # logger.debug(f"Removing child: {child.name}")
                result.remove(child.name)
            remove_bones_tree.update(child.children)

        return result

    def get_bone_name(self) -> str:
        if not self.bone_uuid:
            return ""
        if not self.armature_data_name:
            return ""
        armature_data = bpy.data.armatures.get(self.armature_data_name)
        if not armature_data:
            return ""

        # TODO: Optimization
        for bone in armature_data.bones:
            if bone.vrm_addon_extension.uuid == self.bone_uuid:
                return str(bone.name)

        return ""

    def set_bone_name(self, value: object) -> None:
        armature: Optional[bpy.types.Object] = None

        # アーマチュアの複製が行われた場合を考えてself.armature_data_nameの振り直しをする
        self.search_one_time_uuid = uuid.uuid4().hex
        for found_armature in bpy.data.objects:
            if found_armature.type != "ARMATURE":
                continue
            if all(
                bone_property_group.search_one_time_uuid != self.search_one_time_uuid
                for bone_property_group in BonePropertyGroup.get_all_bone_property_groups(
                    found_armature
                )
            ):
                continue
            armature = found_armature
            break
        if not armature:
            self.armature_data_name = ""
            self.bone_uuid = ""
            return

        armature_data = armature.data
        if not isinstance(armature_data, bpy.types.Armature):
            self.armature_data_name = ""
            self.bone_uuid = ""
            return

        self.armature_data_name = armature_data.name

        # ボーンの複製が行われた場合を考えてUUIDの重複がある場合再割り当てを行う
        found_uuids = set()
        for bone in armature_data.bones:
            found_uuid = bone.vrm_addon_extension.uuid
            if not found_uuid or found_uuid in found_uuids:
                bone.vrm_addon_extension.uuid = uuid.uuid4().hex
            found_uuids.add(bone.vrm_addon_extension.uuid)

        value_str = str(value)
        if not value_str or value_str not in armature_data.bones:
            if not self.bone_uuid:
                return
            self.bone_uuid = ""
        elif (
            self.bone_uuid
            and self.bone_uuid
            == armature_data.bones[value_str].vrm_addon_extension.uuid
        ):
            return
        else:
            bone = armature_data.bones[value_str]
            self.bone_uuid = bone.vrm_addon_extension.uuid

        ext = armature_data.vrm_addon_extension
        for collider_group in ext.vrm0.secondary_animation.collider_groups:
            collider_group.refresh(armature)

        vrm0_bpy_bone_name_to_human_bone_specification: dict[
            str, vrm0_human_bone.HumanBoneSpecification
        ] = {
            human_bone.node.bone_name: vrm0_human_bone.HumanBoneSpecifications.get(
                vrm0_human_bone.HumanBoneName(human_bone.bone)
            )
            for human_bone in ext.vrm0.humanoid.human_bones
            if human_bone.node.bone_name
            and vrm0_human_bone.HumanBoneName.from_str(human_bone.bone) is not None
        }

        for human_bone in ext.vrm0.humanoid.human_bones:
            if not isinstance(armature.data, bpy.types.Armature):
                continue
            human_bone.update_node_candidates(
                armature.data,
                vrm0_bpy_bone_name_to_human_bone_specification,
            )

        human_bone_name_to_human_bone = (
            ext.vrm1.humanoid.human_bones.human_bone_name_to_human_bone()
        )
        vrm1_bpy_bone_name_to_human_bone_specification: dict[
            str, vrm1_human_bone.HumanBoneSpecification
        ] = {
            human_bone.node.bone_name: vrm1_human_bone.HumanBoneSpecifications.get(
                human_bone_name
            )
            for human_bone_name, human_bone in human_bone_name_to_human_bone.items()
            if human_bone.node.bone_name
        }

        for (
            human_bone_name,
            human_bone,
        ) in human_bone_name_to_human_bone.items():
            if not isinstance(armature.data, bpy.types.Armature):
                continue
            human_bone.update_node_candidates(
                armature.data,
                vrm1_human_bone.HumanBoneSpecifications.get(human_bone_name),
                vrm1_bpy_bone_name_to_human_bone_specification,
            )

    bone_name: bpy.props.StringProperty(  # type: ignore[valid-type]
        name="Bone",  # noqa: F821
        get=get_bone_name,
        set=set_bone_name,
    )

    def get_value(self) -> str:
        logger.warning(
            "BonePropertyGroup.value is deprecated."
            + " Use BonePropertyGroup.bone_name instead."
        )
        return str(self.bone_name)

    def set_value(self, value: str) -> None:
        logger.warning(
            "BonePropertyGroup.value is deprecated."
            + " Use BonePropertyGroup.bone_name instead."
        )
        self.bone_name = value

    # "value" is deprecated. Use "bone_name" instead
    value: bpy.props.StringProperty(  # type: ignore[valid-type]
        name="Bone",  # noqa: F821
        get=get_value,
        set=set_value,
    )
    bone_uuid: bpy.props.StringProperty()  # type: ignore[valid-type]
    armature_data_name: bpy.props.StringProperty()  # type: ignore[valid-type]
    search_one_time_uuid: bpy.props.StringProperty()  # type: ignore[valid-type]
    if TYPE_CHECKING:
        # This code is auto generated.
        # `poetry run ./scripts/property_typing.py`
        bone_name: str  # type: ignore[no-redef]
        value: str  # type: ignore[no-redef]
        bone_uuid: str  # type: ignore[no-redef]
        armature_data_name: str  # type: ignore[no-redef]
        search_one_time_uuid: str  # type: ignore[no-redef]


T_co = TypeVar("T_co", covariant=True)


# 本物は型引数を取らない
class CollectionPropertyProtocol(Protocol[T_co]):
    def add(self) -> T_co:
        ...  # TODO: undocumented

    def __len__(self) -> int:
        ...  # TODO: undocumented

    def __iter__(self) -> Iterator[T_co]:
        ...  # TODO: undocumented

    def clear(self) -> None:
        ...  # TODO: undocumented

    @overload
    def __getitem__(self, index: slice) -> tuple[T_co, ...]:
        ...  # TODO: undocumented

    @overload
    def __getitem__(self, index: int) -> T_co:
        ...  # TODO: undocumented

    def remove(self, index: int) -> None:
        ...  # TODO: undocumented

    def values(self) -> ValuesView[T_co]:
        ...  # TODO: undocumented

    def __contains__(self, value: str) -> bool:
        ...  # TODO: undocumented

    def move(self, from_index: int, to_index: int) -> None:
        ...  # TODO: undocumented
